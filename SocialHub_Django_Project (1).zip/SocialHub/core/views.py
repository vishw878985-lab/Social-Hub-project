from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, redirect, render

from .forms import CommentForm, PostForm, ProfileForm, RegisterForm, UserUpdateForm
from .models import Comment, Follow, Like, Post


def home(request):
    if request.user.is_authenticated:
        following_ids = Follow.objects.filter(
            follower=request.user
        ).values_list("following_id", flat=True)

        posts = Post.objects.filter(
            Q(author=request.user) | Q(author_id__in=following_ids)
        ).select_related("author").prefetch_related("likes", "comments")

        # If the user follows nobody, show recent posts too so the feed is not empty.
        if not posts.exists():
            posts = Post.objects.select_related("author").prefetch_related(
                "likes", "comments"
            )[:30]
    else:
        posts = Post.objects.select_related("author").prefetch_related(
            "likes", "comments"
        )[:12]

    return render(request, "home.html", {"posts": posts})


def register_view(request):
    if request.user.is_authenticated:
        return redirect("home")

    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Account created successfully.")
            return redirect("home")
    else:
        form = RegisterForm()

    return render(request, "registration/register.html", {"form": form})


@login_required
def profile_view(request, username):
    profile_user = get_object_or_404(User, username=username)
    posts = Post.objects.filter(author=profile_user).select_related("author")
    followers_count = Follow.objects.filter(following=profile_user).count()
    following_count = Follow.objects.filter(follower=profile_user).count()
    is_following = (
        request.user.is_authenticated
        and Follow.objects.filter(
            follower=request.user, following=profile_user
        ).exists()
    )

    return render(
        request,
        "profile.html",
        {
            "profile_user": profile_user,
            "posts": posts,
            "followers_count": followers_count,
            "following_count": following_count,
            "is_following": is_following,
        },
    )


@login_required
def edit_profile(request):
    profile = request.user.profile

    if request.method == "POST":
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = ProfileForm(
            request.POST, request.FILES, instance=profile
        )
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, "Profile updated successfully.")
            return redirect("profile", username=request.user.username)
    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = ProfileForm(instance=profile)

    return render(
        request,
        "edit_profile.html",
        {"user_form": user_form, "profile_form": profile_form},
    )


@login_required
def create_post(request):
    if request.method == "POST":
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            messages.success(request, "Post published.")
            return redirect("home")
    else:
        form = PostForm()

    return render(request, "post_form.html", {"form": form, "title": "Create Post"})


def post_detail(request, pk):
    post = get_object_or_404(
        Post.objects.select_related("author").prefetch_related("comments__user", "likes"),
        pk=pk,
    )
    comment_form = CommentForm()
    return render(
        request,
        "post_detail.html",
        {"post": post, "comment_form": comment_form},
    )


@login_required
def edit_post(request, pk):
    post = get_object_or_404(Post, pk=pk)

    if post.author != request.user:
        messages.error(request, "You can edit only your own posts.")
        return redirect("post_detail", pk=pk)

    if request.method == "POST":
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            messages.success(request, "Post updated.")
            return redirect("post_detail", pk=pk)
    else:
        form = PostForm(instance=post)

    return render(request, "post_form.html", {"form": form, "title": "Edit Post"})


@login_required
def delete_post(request, pk):
    post = get_object_or_404(Post, pk=pk)

    if post.author != request.user:
        messages.error(request, "You can delete only your own posts.")
        return redirect("post_detail", pk=pk)

    if request.method == "POST":
        post.delete()
        messages.success(request, "Post deleted.")
        return redirect("home")

    return render(request, "confirm_delete.html", {"post": post})


@login_required
def toggle_like(request, pk):
    post = get_object_or_404(Post, pk=pk)

    if request.method == "POST":
        like, created = Like.objects.get_or_create(user=request.user, post=post)
        if not created:
            like.delete()

    return redirect(request.POST.get("next") or request.META.get("HTTP_REFERER") or "home")


@login_required
def add_comment(request, pk):
    post = get_object_or_404(Post, pk=pk)

    if request.method == "POST":
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.user = request.user
            comment.save()
            messages.success(request, "Comment added.")

    return redirect("post_detail", pk=pk)


@login_required
def toggle_follow(request, user_id):
    target_user = get_object_or_404(User, pk=user_id)

    if target_user == request.user:
        messages.error(request, "You cannot follow yourself.")
        return redirect("profile", username=target_user.username)

    if request.method == "POST":
        follow, created = Follow.objects.get_or_create(
            follower=request.user, following=target_user
        )
        if not created:
            follow.delete()

    next_url = request.POST.get("next") or request.META.get("HTTP_REFERER")
    if next_url:
        return redirect(next_url)
    return redirect("profile", username=target_user.username)


def search_users(request):
    query = request.GET.get("q", "").strip()
    users = User.objects.none()

    if query:
        users = User.objects.filter(
            Q(username__icontains=query)
            | Q(first_name__icontains=query)
            | Q(last_name__icontains=query)
        ).order_by("username")[:30]

    return render(request, "search.html", {"query": query, "users": users})
