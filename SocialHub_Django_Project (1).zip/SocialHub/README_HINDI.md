# SocialHub – Content Management System Using Django

Yeh project aapke synopsis ke according banaya gaya hai:
- Python + Django
- SQLite3
- HTML, CSS, JavaScript
- Tailwind CSS (CDN)
- User registration/login/logout
- Profile management
- Create/edit/delete posts
- Image upload
- Like/unlike
- Comments
- Follow/unfollow
- User search
- Personalized feed
- Admin panel

## 1. VS Code me project open karein

ZIP extract karke `SocialHub` folder ko VS Code me Open Folder karein.

## 2. Virtual environment

Windows PowerShell:
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

Agar PowerShell execution policy error aaye:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```
phir activate karein.

CMD:
```cmd
python -m venv venv
venv\Scripts\activate
```

## 3. Packages install

```bash
pip install -r requirements.txt
```

## 4. Database

```bash
python manage.py makemigrations
python manage.py migrate
```

## 5. Admin user

```bash
python manage.py createsuperuser
```

Username, email aur password enter karein.

## 6. Run

```bash
python manage.py runserver
```

Browser:
http://127.0.0.1:8000/

Admin:
http://127.0.0.1:8000/admin/

## Important
Image upload ke liye Pillow install hona zaroori hai.
Project run karte waqt `media` folder automatically use hoga.

## Main URLs
- `/` Home/feed
- `/register/`
- `/login/`
- `/logout/`
- `/profile/<username>/`
- `/profile/edit/`
- `/post/create/`
- `/post/<id>/edit/`
- `/post/<id>/delete/`
- `/post/<id>/like/`
- `/post/<id>/comment/`
- `/user/<id>/follow/`
- `/search/`
- `/admin/`
