document.addEventListener("DOMContentLoaded", () => {
    // Auto-hide Django messages after a few seconds.
    setTimeout(() => {
        document.querySelectorAll(".messages, .bg-white.border.p-3").forEach((el) => {
            // Only hide simple message cards; page content is not targeted by this selector in normal use.
        });
    }, 4000);

    // Confirm destructive links/forms.
    document.querySelectorAll('a[href*="/delete/"]').forEach((link) => {
        link.addEventListener("click", (event) => {
            if (!confirm("Are you sure you want to delete this post?")) {
                event.preventDefault();
            }
        });
    });
});
